const express = require('express');
const Post = require('../models/post'); // Import the Post model
const router = express.Router();

// Create a new post
router.post('/', async (req, res) => {
  const { title, content, user } = req.body;

  if (!title || !content || !user) {
    return res.status(400).send('Title, content, and user are required!');
  }

  try {
    const post = new Post({ title, content, user });
    await post.save();
    res.status(201).send(post);
  } catch (err) {
    res.status(500).send('Error creating post: ' + err.message);
  }
});

// Get all posts
router.get('/', async (req, res) => {
  try {
    const posts = await Post.find().populate('user', 'name email');
    res.status(200).send(posts);
  } catch (err) {
    res.status(500).send('Error fetching posts: ' + err.message);
  }
});

// Get a specific post
router.get('/:id', async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('user', 'name email');
    if (!post) return res.status(404).send('Post not found');
    res.status(200).send(post);
  } catch (err) {
    res.status(500).send('Error fetching post: ' + err.message);
  }
});

// Update a post
router.put('/:id', async (req, res) => {
  const { title, content } = req.body;

  try {
    const post = await Post.findByIdAndUpdate(
      req.params.id,
      { title, content },
      { new: true, runValidators: true }
    );
    if (!post) return res.status(404).send('Post not found');
    res.status(200).send(post);
  } catch (err) {
    res.status(500).send('Error updating post: ' + err.message);
  }
});

// Delete a post
router.delete('/:id', async (req, res) => {
  try {
    const post = await Post.findByIdAndDelete(req.params.id);
    if (!post) return res.status(404).send('Post not found');
    res.status(200).send('Post deleted successfully');
  } catch (err) {
    res.status(500).send('Error deleting post: ' + err.message);
  }
});

module.exports = router;
