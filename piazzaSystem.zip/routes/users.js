// Import required modules
const express = require('express'); // Web framework for handling HTTP requests
const router = express.Router(); // Create a new router instance
const User = require('../models/user'); // Import the User model (database schema)

// **GET route to fetch all users**
router.get('/', async (req, res) => {
  try {
    // Retrieve all users from the database, selecting only `name` and `email`
    const users = await User.find({}, 'name email');
    res.status(200).send(users); // Respond with the list of users
  } catch (error) {
    res.status(500).send('Error fetching users: ' + error.message); // Send error if something goes wrong
  }
});

// **POST route to create a new user**
router.post('/create', async (req, res) => {
  // Get `name`, `email`, and `password` from the request body
  const { name, email, password } = req.body;

  // Check if all required fields are provided
  if (!name || !email || !password) {
    return res.status(400).send('Name, email, and password are required!'); // Send error if fields are missing
  }

  try {
    // Create a new user object with the data
    const newUser = new User({ name, email, password });

    // Save the new user to the database
    await newUser.save();

    // Respond with success message
    res.status(201).send(`User ${name} with email ${email} created successfully!`);
  } catch (error) {
    // Send error if something goes wrong
    res.status(500).send('Error creating user: ' + error.message);
  }
});

// **PUT route to update user details**
router.put('/update', async (req, res) => {
  // Get `currentEmail`, `name`, and `email` from the request body
  const { currentEmail, name, email } = req.body;

  // Check if `currentEmail` is provided
  if (!currentEmail) {
    return res.status(400).send('Current email is required to update user information!');
  }

  try {
    // Find a user by their current email and update their details
    const updatedUser = await User.findOneAndUpdate(
      { email: currentEmail }, // Find user with this email
      { name, email }, // Update these fields
      { new: true, runValidators: true } // Return the updated user and validate fields
    );

    // If no user is found, send a "not found" message
    if (!updatedUser) {
      return res.status(404).send('User not found!');
    }

    // Respond with the updated user details
    res.status(200).send(`User updated successfully: ${JSON.stringify(updatedUser)}`);
  } catch (error) {
    // Send error if something goes wrong
    res.status(500).send('Error updating user: ' + error.message);
  }
});

// **DELETE route to remove a user**
router.delete('/delete', async (req, res) => {
  // Get `email` from the request body
  const { email } = req.body;

  // Check if `email` is provided
  if (!email) {
    return res.status(400).send('Email is required to delete a user!');
  }

  try {
    // Find a user by email and delete them from the database
    const deletedUser = await User.findOneAndDelete({ email });

    // If no user is found, send a "not found" message
    if (!deletedUser) {
      return res.status(404).send('User not found!');
    }

    // Respond with a success message
    res.status(200).send(`User with email ${email} deleted successfully!`);
  } catch (error) {
    // Send error if something goes wrong
    res.status(500).send('Error deleting user: ' + error.message);
  }
});

// Export the router so it can be used in the main app
module.exports = router;
